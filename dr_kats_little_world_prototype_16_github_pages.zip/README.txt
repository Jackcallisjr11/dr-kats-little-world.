# Dr. Kat's Little World — Prototype 16

This is the cumulative, single-file HTML build prepared for free static hosting.

## Test locally
1. Open `index.html` in a modern browser.
2. On mobile, use the on-screen joystick and INTERACT button.
3. Open Settings to run the built-in game checks.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **Public** repository.
2. Name it `dr-kats-little-world` (or another name you like).
3. Upload `index.html` from this folder to the repository root.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then press **Save**.
7. Wait for GitHub Pages to publish. The public address will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/dr-kats-little-world/`

## Important notes
- This project is a static HTML game; it does not require a server or paid hosting.
- Game progress currently uses browser local storage on that device/browser.
- Local storage does not automatically sync between devices.
- Audio playback requires a user gesture in the browser.
- The built-in checks inspect key interface elements and local storage availability;
  they are not a substitute for testing on the target phone.
- Keep the repository public if you want to use GitHub Pages on the free plan.
